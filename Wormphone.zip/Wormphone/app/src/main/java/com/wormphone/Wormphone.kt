package com.wormphone

import android.app.*
import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.StaticLayout
import android.text.TextPaint
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.*
import java.net.*
import java.util.*
import kotlin.math.*

object Skins {
    val names = listOf("Snake", "Budgie", "Cockatiel", "OG Nokia", "Minecraft Creeper", "Mario")
    // g=your colour k=black w=white y=yellow r=red b=blue o=orange p=peach s=grey l=lcd green
    val art = listOf(
        arrayOf("..gggg..", ".gkggkg.", ".gggggg.", "..grrg..", "...gg...", ".gggg...", "gg.ggg..", ".gggggg."),
        arrayOf("..yyy...", ".yykyy..", ".yyyoy..", "..gggg..", ".gggggg.", ".gggggg.", "..gggg..", "..o..o.."),
        arrayOf("...y....", "..yyy...", ".yykyo..", ".yyyyy..", "..ssss..", ".ssssss.", "..ssss..", "..y..y.."),
        arrayOf(".bbbbbb.", ".bllllb.", ".bllllb.", ".bbbbbb.", ".bwbwbb.", ".bbwbwb.", ".bwbwbb.", ".bbbbbb."),
        arrayOf("gggggggg", "gkkggkkg", "gkkggkkg", "gggkkggg", "ggkkkkgg", "ggkkkkgg", "ggkggkgg", "gggggggg"),
        arrayOf("..rrrr..", ".rrrrrrr", "..ppkpp.", ".pppppp.", "..rrrr..", ".rrbbrr.", ".rbbbbr.", "..b..b..")
    )
    fun color(c: Char, tint: Int) = when (c) {
        'g' -> tint; 'k' -> Color.BLACK; 'w' -> Color.WHITE; 'y' -> Color.rgb(255, 220, 40)
        'r' -> Color.rgb(220, 40, 40); 'b' -> Color.rgb(40, 80, 220); 'o' -> Color.rgb(255, 140, 0)
        'p' -> Color.rgb(255, 204, 153); 's' -> Color.rgb(150, 150, 160); 'l' -> Color.rgb(160, 210, 120)
        else -> 0
    }
}

class PetView(c: Context) : View(c) {
    var skin = 0; var tint = Color.GREEN; var flip = false; var score = 0
    private var bubble: String? = null; private var until = 0L
    private val d = resources.displayMetrics.density
    private val p = Paint(); private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11 * d }
    fun say(t: String) { bubble = t; until = System.currentTimeMillis() + 5000 }
    override fun onDraw(cv: Canvas) {
        val size = height * 2f / 3; val left = (width - size) / 2; val top = height - size
        val cell = size / 8; val bob = (sin(System.currentTimeMillis() / 200.0) * 2 * d).toFloat()
        Skins.art[skin % Skins.art.size].forEachIndexed { r, row ->
            for (i in 0 until 8) {
                val col = Skins.color(row[if (flip) 7 - i else i], tint)
                if (col != 0) { p.color = col; cv.drawRect(left + i * cell, top + r * cell + bob, left + (i + 1) * cell, top + (r + 1) * cell + bob, p) }
            }
        }
        if (System.currentTimeMillis() < until) bubble?.let {
            val l = StaticLayout.Builder.obtain(it, 0, it.length, tp, (width - 24 * d).toInt()).build()
            p.color = Color.WHITE; cv.drawRoundRect(2f, 2f, width - 2f, l.height + 14 * d, 12f, 12f, p)
            cv.save(); cv.translate(12 * d, 7 * d); l.draw(cv); cv.restore()
        }
    }
}

class DotView(c: Context) : View(c) {
    val list = ArrayList<PointF>(); private val p = Paint().apply { color = Color.rgb(255, 215, 0) }
    override fun onDraw(cv: Canvas) { val s = 5 * resources.displayMetrics.density; list.forEach { cv.drawRect(it.x - s, it.y - s, it.x + s, it.y + s, p) } }
}

class Link(ctx: Context, val onGot: (Int, Int) -> Unit) {
    private val cl = Nearby.getConnectionsClient(ctx); val peers = HashSet<String>()
    private val me = UUID.randomUUID().toString()
    private val pl = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) { val s = String(p.asBytes()!!).split(","); onGot(s[0].toInt(), s[1].toInt()) }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }
    private val cb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, i: ConnectionInfo) { cl.acceptConnection(id, pl) }
        override fun onConnectionResult(id: String, r: ConnectionResolution) { if (r.status.isSuccess) peers.add(id) }
        override fun onDisconnected(id: String) { peers.remove(id) }
    }
    fun start() {
        val s = Strategy.P2P_CLUSTER
        cl.startAdvertising(me, "wormphone", cb, AdvertisingOptions.Builder().setStrategy(s).build())
        cl.startDiscovery("wormphone", object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) { if (me < i.endpointName) cl.requestConnection(me, id, cb) }
            override fun onEndpointLost(id: String) {}
        }, DiscoveryOptions.Builder().setStrategy(s).build())
    }
    fun send(skin: Int, color: Int) { cl.sendPayload(peers.toList(), Payload.fromBytes("$skin,$color".toByteArray())) }
    fun stop() { cl.stopAllEndpoints(); cl.stopAdvertising(); cl.stopDiscovery() }
}

object Brain {
    // name, url, model, isAnthropic  (edit models here if a provider retires one)
    class P(val name: String, val url: String, val model: String, val anthropic: Boolean = false)
    val providers = listOf(
        P("Anthropic", "https://api.anthropic.com/v1/messages", "claude-haiku-5-5", true),
        P("OpenAI", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini"),
        P("DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat"),
        P("Groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.1-8b-instant")
    )
    fun say(prov: Int, key: String, skin: String, done: (String) -> Unit) = Thread {
        try {
            val auto = when {   // key prefix wins over the selected provider
                key.startsWith("gsk_") -> 3
                key.startsWith("sk-ant") -> 0
                key.startsWith("sk-proj") -> 1
                else -> prov
            }
            val pr = providers[auto % providers.size]
            val c = URL(pr.url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            if (pr.anthropic) { c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01") }
            else c.setRequestProperty("Authorization", "Bearer $key")
            val msg = "You are a tiny pixel pet ($skin skin) living on a phone screen. Say one funny line, max 10 words."
            val body = JSONObject().put("model", pr.model).put("max_tokens", 40)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", msg)))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val r = JSONObject(c.inputStream.bufferedReader().readText())
            done(if (pr.anthropic) r.getJSONArray("content").getJSONObject(0).getString("text")
                 else r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"))
        } catch (e: Exception) {}
    }.start()
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager; private lateinit var pet: PetView; private lateinit var dots: DotView
    private lateinit var lp: LP; private lateinit var link: Link
    private val h = Handler(Looper.getMainLooper()); private val rnd = Random()
    private val prefs by lazy { getSharedPreferences("wp", 0) }
    private var sw = 0; private var sh = 0; private var size = 0; private var pw = 0; private var ph = 0
    private var vx = 0f; private var vy = 0f; private var dragging = false; private var present = true; private var tn = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("wp", "Wormphone", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "wp").setContentTitle("Wormphone is alive").setSmallIcon(android.R.drawable.ic_menu_compass).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics; sw = dm.widthPixels; sh = dm.heightPixels
        size = (96 * dm.density).toInt(); pw = size * 2; ph = size * 3 / 2
        val t = LP.TYPE_APPLICATION_OVERLAY
        dots = DotView(this)
        wm.addView(dots, LP(-1, -1, t, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT))
        pet = PetView(this)
        lp = LP(pw, ph, t, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = sw / 2; y = sh / 2 }
        wm.addView(pet, lp)
        pet.setOnTouchListener(touch())
        link = Link(this) { s, c -> h.post { receive(s, c) } }
        try { link.start() } catch (e: Exception) {}
        h.post(tick)
    }

    private fun touch(): View.OnTouchListener {
        var ox = 0f; var oy = 0f; var vt: VelocityTracker? = null
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dragging = true; ox = e.rawX - lp.x; oy = e.rawY - lp.y; vt = VelocityTracker.obtain() }
                MotionEvent.ACTION_MOVE -> { vt?.addMovement(e); lp.x = (e.rawX - ox).toInt(); lp.y = (e.rawY - oy).toInt(); wm.updateViewLayout(pet, lp) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                    val fx = vt?.xVelocity ?: 0f; val fy = vt?.yVelocity ?: 0f; vt?.recycle(); dragging = false
                    if (hypot(fx, fy) > 2500 && link.peers.isNotEmpty()) {
                        link.send(prefs.getInt("skin", 0), prefs.getInt("color", 0xFF43A047.toInt()))
                        present = false; pet.visibility = View.GONE   // thrown into the other phone
                    } else { vx = fx / 60; vy = fy / 60 }
                }
            }
            true
        }
    }

    private fun receive(skin: Int, color: Int) {
        prefs.edit().putInt("skin", skin).putInt("color", color).apply()
        present = true; pet.visibility = View.VISIBLE
        val left = rnd.nextBoolean(); lp.x = if (left) 0 else sw - pw; lp.y = rnd.nextInt(max(1, sh - ph))
        vx = if (left) 15f else -15f; vy = 0f; wm.updateViewLayout(pet, lp)
    }

    private val tick = object : Runnable {
        override fun run() {
            tn++
            pet.skin = prefs.getInt("skin", 0); pet.tint = prefs.getInt("color", 0xFF43A047.toInt())
            if (present && !dragging) {
                val cx = lp.x + pw / 2f; val cy = lp.y + ph - size / 2f
                if (tn % 60 == 0 && dots.list.size < 5) dots.list.add(PointF(20 + rnd.nextFloat() * (sw - 40), 100 + rnd.nextFloat() * (sh - 250)))
                val d = dots.list.minByOrNull { hypot(it.x - cx, it.y - cy) }
                if (d != null) {
                    val dist = hypot(d.x - cx, d.y - cy)
                    if (dist < size / 2f) { dots.list.remove(d); pet.score++ } else { vx += (d.x - cx) / dist * .7f; vy += (d.y - cy) / dist * .7f }
                }
                vx *= .95f; vy *= .95f; lp.x += vx.toInt(); lp.y += vy.toInt()
                if (lp.x < 0 || lp.x > sw - pw) { vx = -vx; lp.x = lp.x.coerceIn(0, sw - pw) }
                if (lp.y < 0 || lp.y > sh - ph) { vy = -vy; lp.y = lp.y.coerceIn(0, sh - ph) }
                if (abs(vx) > .5f) pet.flip = vx < 0
                wm.updateViewLayout(pet, lp)
            }
            dots.invalidate(); pet.invalidate()
            val key = prefs.getString("key", "") ?: ""
            if (tn % 750 == 0 && present && prefs.getBoolean("ai", false) && key.isNotBlank())
                Brain.say(prefs.getInt("prov", 0), key, Skins.names[pet.skin % Skins.names.size]) { s -> h.post { pet.say(s) } }
            h.postDelayed(this, 33)
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); link.stop()
        try { wm.removeView(pet); wm.removeView(dots) } catch (e: Exception) {}
        super.onDestroy()
    }
}

class MainActivity : Activity() {
    private lateinit var key: EditText
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("wp", 0); val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun btn(t: String, f: () -> Unit) { col.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        btn("1. Allow drawing over apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Allow notifications + nearby phones") {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.ACCESS_FINE_LOCATION", "android.permission.BLUETOOTH_SCAN",
                "android.permission.BLUETOOTH_ADVERTISE", "android.permission.BLUETOOTH_CONNECT", "android.permission.NEARBY_WIFI_DEVICES"), 1)
        }
        btn("Start worm") {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java))
            else Toast.makeText(this, "Do step 1 first", Toast.LENGTH_LONG).show()
        }
        btn("Stop worm") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Next skin") {
            val n = (p.getInt("skin", 0) + 1) % Skins.names.size; p.edit().putInt("skin", n).apply()
            Toast.makeText(this, Skins.names[n], Toast.LENGTH_SHORT).show()
        }
        btn("Random colour") { p.edit().putInt("color", Color.HSVToColor(floatArrayOf(Random().nextInt(360).toFloat(), .7f, .9f))).apply() }
        btn("AI provider: " + Brain.providers[p.getInt("prov", 0)].name + " (tap to switch)") {
            val n = (p.getInt("prov", 0) + 1) % Brain.providers.size; p.edit().putInt("prov", n).apply()
            Toast.makeText(this, "Provider: " + Brain.providers[n].name, Toast.LENGTH_SHORT).show()
        }
        key = EditText(this).apply { hint = "API key for the chosen provider (optional)"; setText(p.getString("key", "")) }
        col.addView(key)
        col.addView(Switch(this).apply {
            text = "Let the worm talk (needs API key)"; isChecked = p.getBoolean("ai", false)
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("ai", c).apply() }
        })
        btn("Pick a GGUF model (offline, coming soon)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 7)
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
    override fun onPause() { super.onPause(); getSharedPreferences("wp", 0).edit().putString("key", key.text.toString().trim()).apply() }
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 7 && d?.data != null) getSharedPreferences("wp", 0).edit().putString("gguf", d.data.toString()).apply()
    }
}
